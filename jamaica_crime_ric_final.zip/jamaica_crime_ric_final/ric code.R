#changing column names and removing excess columns
colnames(ja_data)<- c('year','int_hom','murders','pop','GDP_gr','inflation','ex_rate')
colnames(tt_data)<- c('year','int_hom','murders','pop','GDP_gr','inflation','ex_rate')
colnames(hom_data)<-c('year','int_hom','murders','pop','GDP_gr','inflation','ex_rate','country','pop_grow','gdp_per_cap','gdp','gdp_per_cap_gr')
ja_data$hc<-NULL
tt_data$hc<-NULL
hom_data$hc<-NULL
rm(hom_data)


#creating binary variable
hom_data$ja<-ifelse(hom_data$country=="jamaica",1,0)
hom_data$cja<-ifelse(hom_data$year>=2014,1,0)
hom_data$tt<-ifelse(hom_data$country=="trinidad",1,0)

#creating plots
library(tidyverse)
ggplot(data = hom_data) + 
  geom_line(mapping = aes(x = year, y = murders, color=interaction(country, sep=':')))+ggtitle("Annual Murder Count Per Country")+labs(x="Year",y="Murders")+labs(color="Country")+theme(legend.position = "bottom")+scale_color_hue(labels=c("Jamaica","Trinidad and Tobago"))

ggplot(data = hom_data) + 
  geom_line(mapping = aes(x = year, y = int_hom, color=interaction(country, sep=':')))+ggtitle("Annual Intentional Homicide Rate Per Country")+labs(x="Year",y="Intentional Homicide Rate (Per 100k people)")+labs(x="Year",y="Murders")+labs(color="Country")+theme(legend.position = "bottom")+scale_color_hue(labels=c("Jamaica","Trinidad and Tobago"))

#testing correlation
cor(ja_data$int_hom,ja_data$murders)
cor(tt_data$int_hom,tt_data$murders)
cor(ja_data$hc,ja_data$murders)


#regression analysis

ols_murdersja<-lm(murders~pop+GDP_gr+inflation+ex_rate, data = ja_data)
summary(ols_murdersja)
ols_inthomja<-lm(formula = int_hom~pop+GDP_gr+inflation+ex_rate, data = ja_data)
summary(ols_inthomja)

library(stargazer)
stargazer(ols_inthomja,ols_murdersja, type="text")

#regression analysis trinidad
ols_murderstt<-lm(murders~pop+GDP_gr+inflation+ex_rate, data = tt_data)
summary(ols_murderstt)
ols_inthomtt<-lm(formula = int_hom~pop+GDP_gr+inflation+ex_rate, data = tt_data)
summary(ols_inthomtt)

stargazer(ols_inthomtt,ols_murderstt, type="text")

#DiD regression Jamaica
ols_did_murdersja<-lm(murders~cja+ja+cja*ja+pop_grow+gdp_per_cap+inflation+ex_rate,data=hom_data)
summary(ols_did_murdersja)
ols_did_inthomja<-lm(int_hom~cja+ja+cja*ja+pop+GDP_gr+inflation+ex_rate,data = hom_data)
summary(ols_did_inthomja)

stargazer(ols_did_inthomja,ols_did_murdersja, type="text")

#DiD regression Trinidad
ols_did_inthomtt<-lm(int_hom~cja+tt+cja*tt+pop+GDP_gr+inflation+ex_rate,data = hom_data)
summary(ols_did_inthomtt)
ols_did_murderstt<-lm(murders~cja+tt+cja*tt+pop+GDP_gr+inflation+ex_rate,data = hom_data)
summary(ols_did_murderstt)
library(stargazer)
stargazed<-stargazer(ols_did_inthomtt,ols_did_murderstt, type="text")

#year fixed effects
install.packages('plm')
library(plm)
time_fixedmurders<-plm(murders~pop+GDP_gr+inflation+ex_rate+factor(year),index="year",model="within", data = hom_data)
summary(time_fixedmurders)
time_fixedinthom<-plm(int_hom~pop+GDP_gr+inflation+ex_rate+factor(year),index="year",model="within", data = hom_data)
summary(time_fixedinthom)

stargazer(time_fixedinthom,time_fixedmurders, type = "text")
#summary statistics for jamaica
mean(ja_data$int_hom)
max(ja_data$int_hom)
min(ja_data$int_hom)

ja_data %>%
  group_by(ja_data$year>=2014) %>%
  summarise(mean=mean(int_hom), n=n())
ja_data %>%
  group_by(ja_data$year>=2014) %>%
  summarise(min=min(int_hom), n=n())
ja_data %>%
  group_by(ja_data$year>=2014) %>%
  summarise(max=max(int_hom), n=n())  

mean(ja_data$murders)
max(ja_data$murders)
min(ja_data$murders)

ja_data %>%
  group_by(ja_data$year>=2014) %>%
  summarise(mean=mean(murders), n=n())
ja_data %>%
  group_by(ja_data$year>=2014) %>%
  summarise(min=min(murders), n=n())
ja_data %>%
  group_by(ja_data$year>=2014) %>%
  summarise(max=max(murders), n=n())    



#summary statistics for trinidad and tobago                              
mean(tt_data$int_hom)
max(tt_data$int_hom) 
min(tt_data$int_hom)

tt_data %>%
  group_by(tt_data$year>=2014) %>%
  summarise(mean=mean(int_hom), n=n())
tt_data %>%
  group_by(tt_data$year>=2014) %>%
  summarise(min=min(int_hom), n=n())
tt_data %>%
  group_by(tt_data$year>=2014) %>%
  summarise(max=max(int_hom), n=n())  

mean(tt_data$murders)
max(tt_data$murders)
min(tt_data$murders)

tt_data %>%
  group_by(tt_data$year>=2014) %>%
  summarise(mean=mean(murders), n=n())
tt_data %>%
  group_by(tt_data$year>=2014) %>%
  summarise(min=min(murders), n=n())
tt_data %>%
  group_by(tt_data$year>=2014) %>%
  summarise(max=max(murders), n=n())    

#testing correlation
cor(ja_data$int_hom,ja_data$murders)
cor(tt_data$int_hom,tt_data$murders)

cor(hom_data[,c('year','int_hom','murders','pop','GDP_gr','inflation','ex_rate')])

#mean diff t test
ja_data %>%
  group_by(ja_data$year>=2014) %>%
  summarise(sd=sd(int_hom), n=n())
tt_data %>%
  group_by(tt_data$year>=2014) %>%
  summarise(sd=sd(murders), n=n()) 

cjabef<-rnorm(20,mean = 20.6,sd=10.3)
cjaafter<-rnorm(6,mean = 34.3,sd=6.99)

t.test(cjabef,cjaafter)

ttbef<-rnorm(20, mean=20.6,sd=156)
ttafter<-rnorm(6,mean=34.3,sd=55.6)

t.test(ttbef, ttafter)

#if the criminal justice act was effective I would expect to see a 
#statistically significant decrease in the homicide rates during the treatment period 

#turning scripts to latex/latec
library(tidyverse)
install.packages("broom")
library(broom)
install.packages("knitr")
library(knitr)

library(rmarkdown)
sink(file = "ric code.txt")
"ja ols"
stargazer(ols_inthomja,ols_murdersja, type="text")
"tt ols"
stargazer(ols_inthomtt,ols_murderstt, type="text")
"ja did"
stargazer(ols_did_inthomja,ols_did_murdersja, type="text")
"time fixed"
stargazer(ols_time_inthomja,ols_time_murdersja,type="text")
"corr"
cor(hom_data[,c('year','int_hom','murders','pop','GDP_gr','inflation','ex_rate')])
sink()

getwd()
#DiD for year only 
ols_time_murdersja<-lm(murders~cja+pop+GDP_gr+inflation+ex_rate,data=hom_data)
summary(ols_time_murdersja)
ols_time_inthomja<-lm(int_hom~cja+pop+GDP_gr+inflation+ex_rate,data = hom_data)
summary(ols_time_inthomja)

library(stargazer)
stargazer(ols_time_inthomja,ols_time_murdersja,type="text")
